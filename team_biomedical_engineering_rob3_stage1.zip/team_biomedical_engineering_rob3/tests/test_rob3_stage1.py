from decimal import Decimal
import pandas as pd
from app import initial_state, compute_rob_month, validate_snapshot_import

def test_three_month_fixture():
    state = initial_state()
    params = state["params"]
    var_lines = state["variable_lines"]
    fixed_lines = state["fixed_lines"]
    df = pd.read_csv("sample_data/monthly_fixture.csv")

    expected = [
        {"sold": 30, "rev": Decimal("3600.00"), "exp": Decimal("2550.00"), "prof": Decimal("1050.00"), "cash": Decimal("6950.00"), "stock": 70},
        {"sold": 30, "rev": Decimal("3600.00"), "exp": Decimal("2650.00"), "prof": Decimal("950.00"), "cash": Decimal("8800.00"), "stock": 40},
        {"sold": 22, "rev": Decimal("2640.00"), "exp": Decimal("2030.00"), "prof": Decimal("610.00"), "cash": Decimal("10070.00"), "stock": 18},
    ]

    for idx, row in df.iterrows():
        params["requested_units"] = int(row["requested"])
        params["ad_cost"] = float(row["ad_cost"])
        res = compute_rob_month(params, var_lines, fixed_lines, capacity_override=int(row["capacity_override"]))
        exp = expected[idx]
        assert res["sold"] == exp["sold"]
        assert res["revenue"] == exp["rev"]
        assert res["total_expense"] == exp["exp"]
        assert res["operating_profit"] == exp["prof"]
        assert res["ending_cash"] == exp["cash"]
        assert res["ending_stock_units"] == exp["stock"]
        params["opening_cash"] = float(res["ending_cash"])
        params["opening_stock_units"] = int(res["ending_stock_units"])

def test_rob_business_specific_stock_limit():
    state = initial_state()
    params = state["params"]
    params["opening_stock_units"] = 10
    params["defect_rate"] = 0.0
    params["restock_units"] = 0
    params["requested_units"] = 40
    res = compute_rob_month(params, state["variable_lines"], state["fixed_lines"])
    assert res["sold"] == 10
    assert res["revenue"] == Decimal("1200.00")
    assert res["total_expense"] == Decimal("1250.00")
    assert res["operating_profit"] == Decimal("-50.00")
    assert res["ending_stock_units"] == 0

def test_zero_sales_and_validation():
    state = initial_state()
    state["params"]["requested_units"] = 0
    res = compute_rob_month(state["params"], state["variable_lines"], state["fixed_lines"])
    assert res["revenue"] == Decimal("0.00")
    assert res["variable_expense"] == Decimal("0.00")
    assert res["operating_profit"] == Decimal("-600.00")

    bad_team = {"team_id": "other-team", "course": "AP Calculus", "pathway_id": "ROB-3", "snapshot_id": "s1", "state_version": 2, "params": {}}
    ok, _ = validate_snapshot_import(bad_team, "team-biomedical-engineering", 1)
    assert not ok

    stale = {"team_id": "team-biomedical-engineering", "course": "AP Calculus", "pathway_id": "ROB-3", "snapshot_id": "s0", "state_version": 1, "params": {}}
    ok2, _ = validate_snapshot_import(stale, "team-biomedical-engineering", 2)
    assert not ok2
